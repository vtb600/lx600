"""
Ứng dụng đọc hóa đơn XML → hiển thị bảng + xuất Excel
Giao diện: CustomTkinter (Dark mode, màu xanh VietinBank)
"""

import os
import re
import webbrowser
import xml.etree.ElementTree as ET
import tkinter as tk
from tkinter import filedialog, messagebox
import threading
import customtkinter as ctk
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

# ─── Theme ────────────────────────────────────────────────────────────────────
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

BLUE   = "#1F5C99"
BLUE2  = "#2A7BD0"
GREEN  = "#28A745"
RED    = "#DC3545"
ORANGE = "#FD7E14"
BG     = "#1A1D23"
CARD   = "#22262F"
BORDER = "#2E3340"
TEXT   = "#E8ECF0"
MUTED  = "#7B8494"

HEADERS = [
    "Loại", "Số chứng từ", "Ký hiệu", "Ngày lập",
    "Tên đơn vị", "MST đơn vị",
    "Số lít", "Tiền trước thuế", "Tiền thuế", "Tổng tiền",
    "Thời gian GD", "Nội dung"
]

COL_WIDTHS = [70, 90, 70, 90, 320, 130, 
              70, 100, 70, 100, 100, 280]

# ─── XML Logic ────────────────────────────────────────────────────────────────

def get_text(root, xpath):
    node = root.find(xpath)
    return node.text.strip() if node is not None and node.text else ""

def extract_receipt_info(description):
    result = {"bien_so": "", "ma_giao_dich": "", "thoi_gian_gd": ""}
    if not description:
        return result
    m = re.search(r'phương tiện\s+([A-Z0-9]+)', description, re.IGNORECASE)
    if m:
        result["bien_so"] = m.group(1)
    m = re.search(r'mã GD\s+(\d+)', description, re.IGNORECASE)
    if m:
        result["ma_giao_dich"] = m.group(1)
    m = re.search(r'Thời gian giao dịch:\s*([0-9\/:\s]+)', description, re.IGNORECASE)
    if m:
        result["thoi_gian_gd"] = m.group(1).strip()
    return result

def read_xml(xml_file):
    root = ET.parse(xml_file).getroot()
    if root.find(".//SHDon") is not None:
        return {
            "loai": "HOA_DON",
            "so_ct": get_text(root, ".//SHDon"),
            "ky_hieu": get_text(root, ".//KHHDon"),
            "ngay_lap": get_text(root, ".//NLap"),
            "ten_don_vi": get_text(root, ".//NBan/Ten"),
            "mst": get_text(root, ".//NBan/MST"),
            "so_lit": (
                f"{so_lit:,.3f}".replace(",", "X").replace(".", ",").replace("X", ".")
                if 3 < (so_lit := float(get_text(root, ".//SLuong") or 0)) < 100
                else ""
            ),
            "tien_truoc_thue": f"{int(float(get_text(root, './/TgTCThue') or get_text(root, ".//TgTTTBSo"))):,}",
            "tien_thue": f"{int(float(get_text(root, './/TgTThue') or 0)):,}",
            "tong_tien": f"{int(float(get_text(root, './/TgTTTBSo') or 0)):,}",
            "thoi_gian_gd": "", "noi_dung": get_text(root, ".//THHDVu")
        }
    elif root.find(".//SCTu") is not None:
        noi_dung = get_text(root, ".//TLPhi")
        extra = extract_receipt_info(noi_dung)
        return {
            "loai": "BIEN_LAI",
            "so_ct": get_text(root, ".//SCTu"),
            "ky_hieu": get_text(root, ".//KHCTu"),
            "ngay_lap": get_text(root, ".//NLap"),
            "ten_don_vi": get_text(root, ".//TTCThu"),
            "mst": get_text(root, ".//TCTPhi/MST"),
            "so_lit": "",
            "hanghoa": "",
            "tien_truoc_thue": f"{int(float(get_text(root, ".//STien") or 0)):,}",
            "tien_thue": "",
            "tong_tien": f"{int(float(get_text(root, ".//STien") or 0)):,}",
            "thoi_gian_gd": extra["thoi_gian_gd"],
            "noi_dung": noi_dung
        }
    else:
        raise Exception("Không nhận dạng được định dạng XML")

def export_excel(records, output_path):
    wb = Workbook()
    ws = wb.active
    ws.title = "Dữ liệu hóa đơn"

    header_font  = Font(name="Arial", bold=True, color="FFFFFF", size=10)
    header_fill  = PatternFill("solid", start_color="1F5C99")
    header_align = Alignment(horizontal="center", vertical="center", wrap_text=True)
    thin         = Side(style="thin", color="CCCCCC")
    border       = Border(left=thin, right=thin, top=thin, bottom=thin)

    for col, h in enumerate(HEADERS, 1):
        c = ws.cell(row=1, column=col, value=h)
        c.font = header_font; c.fill = header_fill
        c.alignment = header_align; c.border = border
    ws.row_dimensions[1].height = 30

    fill_hd  = PatternFill("solid", start_color="EBF3FB")
    fill_bl  = PatternFill("solid", start_color="FEFEFE")
    data_font  = Font(name="Arial", size=9)
    data_align = Alignment(vertical="center")

    for r, d in enumerate(records, 2):
        row_data = [
            d["loai"], d["so_ct"], d["ky_hieu"], d["ngay_lap"],
            d["ten_don_vi"], d["mst"],
            d["so_lit"], d["tien_truoc_thue"], d["tien_thue"], d["tong_tien"],
            d["thoi_gian_gd"], d["noi_dung"]
        ]
        fill = fill_hd if d["loai"] == "HOA_DON" else fill_bl
        for col, val in enumerate(row_data, 1):
            c = ws.cell(row=r, column=col, value=val)
            c.font = data_font; c.fill = fill
            c.alignment = data_align; c.border = border

    col_widths = [12,14,14,12,30,16,25,16,8,16,12,16,12,16,20,40]
    for i, w in enumerate(col_widths, 1):
        ws.column_dimensions[ws.cell(row=1, column=i).column_letter].width = w

    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    wb.save(output_path)

# ─── Table widget (Tkinter Canvas-based) ─────────────────────────────────────

class DataTable(tk.Frame):
    ROW_H   = 32
    HEAD_H  = 38

    def __init__(self, master, **kw):
        super().__init__(master, bg=BG, **kw)
        self._records = []
        self._build()

    def _build(self):
        # Outer frame with scrollbars
        self.x_scroll = tk.Scrollbar(self, orient="horizontal", bg=CARD,
                                     troughcolor=CARD, activebackground=BLUE2)
        self.y_scroll = tk.Scrollbar(self, orient="vertical", bg=CARD,
                                     troughcolor=CARD, activebackground=BLUE2)

        self.canvas = tk.Canvas(self, bg=BG, highlightthickness=0,
                                xscrollcommand=self.x_scroll.set,
                                yscrollcommand=self.y_scroll.set)

        self.x_scroll.config(command=self.canvas.xview)
        self.y_scroll.config(command=self.canvas.yview)

        self.x_scroll.pack(side="bottom", fill="x")
        self.y_scroll.pack(side="right",  fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)

        self.canvas.bind("<MouseWheel>", self._on_mousewheel)
        self.canvas.bind("<Button-4>",   self._on_mousewheel)
        self.canvas.bind("<Button-5>",   self._on_mousewheel)

        # Inner frame drawn on canvas
        self.inner = tk.Frame(self.canvas, bg=BG)
        self.canvas_window = self.canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.inner.bind("<Configure>", self._on_inner_configure)

    def _on_inner_configure(self, event):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _on_mousewheel(self, event):
        if event.num == 4:
            self.canvas.yview_scroll(-1, "units")
        elif event.num == 5:
            self.canvas.yview_scroll(1, "units")
        else:
            self.canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

    def _clear(self):
        for w in self.inner.winfo_children():
            w.destroy()

    def render(self, records):
        self._records = records
        self._clear()

        total_cols = len(HEADERS)

        # ── Header row ──
        for c, (h, w) in enumerate(zip(HEADERS, COL_WIDTHS)):
            cell = tk.Frame(self.inner, bg=BLUE, width=w, height=self.HEAD_H,
                            highlightbackground=BORDER, highlightthickness=1)
            cell.grid(row=0, column=c, sticky="nsew", padx=0, pady=0)
            cell.grid_propagate(False)
            tk.Label(cell, text=h, bg=BLUE, fg=TEXT,
                     font=("Segoe UI", 8, "bold"),
                     anchor="center", justify="center",
                     wraplength=w-6).place(relx=.5, rely=.5, anchor="center")

        # ── Data rows ──
        for r, d in enumerate(records):
            row_data = [
                d["loai"], d["so_ct"], d["ky_hieu"], d["ngay_lap"],
                d["ten_don_vi"], d["mst"],
                d["so_lit"], d["tien_truoc_thue"], d["tien_thue"], d["tong_tien"],
                d["thoi_gian_gd"], d["noi_dung"]
            ]

            is_hd   = d["loai"] == "HOA_DON"
            row_bg  = "#1E2C3E" if is_hd else "#22262F"
            alt_bg  = "#182436" if is_hd else "#1E2229"
            bg      = row_bg if r % 2 == 0 else alt_bg

            for c, (val, w) in enumerate(zip(row_data, COL_WIDTHS)):
                cell = tk.Frame(self.inner, bg=bg, width=w, height=self.ROW_H,
                                highlightbackground=BORDER, highlightthickness=1)
                cell.grid(row=r+1, column=c, sticky="nsew", padx=0, pady=0)
                cell.grid_propagate(False)

                # Badge for loai column
                if c == 0:
                    badge_bg  = BLUE if is_hd else "#2D5A1B"
                    badge_txt = "📄 HĐ" if is_hd else "🧾 BL"
                    tk.Label(cell, text=badge_txt, bg=badge_bg, fg=TEXT,
                             font=("Segoe UI", 7, "bold"), padx=4, pady=1,
                             relief="flat").place(relx=.5, rely=.5, anchor="center")
                else:
                    fg = MUTED if not val else TEXT
                    tk.Label(cell, text=val or "—", bg=bg, fg=fg,
                             font=("Segoe UI", 8),
                             anchor="w", padx=6).place(relx=0, rely=.5, anchor="w",
                                                        width=w-2)

        # Update scroll region
        self.inner.update_idletasks()
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))


# ─── Main App ─────────────────────────────────────────────────────────────────

class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Hóa Đơn XML Viewer")
        self.geometry("1280x800")
        self.minsize(900, 600)
        self.configure(fg_color=BG)

        self._records   = []
        self._selected_files = []

        self._build_ui()

    # ── UI ─────────────────────────────────────────────────────────────────

    def _build_ui(self):
        # ── Top bar ──
        topbar = ctk.CTkFrame(self, fg_color=CARD, corner_radius=0, height=58)
        topbar.pack(fill="x", side="top")
        topbar.pack_propagate(False)

        ctk.CTkLabel(topbar, text="  📋  LX600v2 - Phong TCTH - VietinBank Binh Thuan",
                     font=ctk.CTkFont("Segoe UI", 18, "bold"),
                     text_color=TEXT).pack(side="left", padx=20, pady=10)

        # Stats badges (right side of topbar)
        self.badge_frame = ctk.CTkFrame(topbar, fg_color="transparent")
        self.badge_frame.pack(side="right", padx=20)
        self.lbl_so_lit       = self._stat_badge(self.badge_frame, "Tổng số lít",       "0",   "#8CD2F7")
        self.lbl_truoc_thue   = self._stat_badge(self.badge_frame, "Trước thuế",    "0",   "#005B94")
        self.lbl_tong_thue    = self._stat_badge(self.badge_frame, "Thuế",     "0",   "#E4537B")
        self.lbl_sau_thue     = self._stat_badge(self.badge_frame, "Sau thuế",      "0",   "#D31145")
        self.lbl_tien_xang     = self._stat_badge(self.badge_frame, "Tiền xăng",      "0",   "#D31145")
        self.lbl_tien_cuoc     = self._stat_badge(self.badge_frame, "Tiền cước",      "0",   "#D31145")
        self.lbl_total  = self._stat_badge(self.badge_frame, "Tổng",  "0", "#8CD2F7")
        self.lbl_hd     = self._stat_badge(self.badge_frame, "Hóa đơn", "0", BLUE)
        self.lbl_bl     = self._stat_badge(self.badge_frame, "Biên lai", "0", "#E4537B")

        # ── Main content (sidebar + table) ──
        content = ctk.CTkFrame(self, fg_color="transparent")
        content.pack(fill="both", expand=True, padx=0, pady=0)

        # Sidebar
        sidebar = ctk.CTkFrame(content, fg_color=CARD, corner_radius=0, width=240)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)

        ctk.CTkLabel(sidebar, text="Giới thiệu",
                     font=ctk.CTkFont("Segoe UI", 13, "bold"),
                     text_color=TEXT).pack(anchor="w", padx=20, pady=(20, 8))

        # Drop zone
        self.drop_zone = ctk.CTkFrame(sidebar, fg_color=BG, corner_radius=10,
                                      border_width=2, border_color=BORDER, height=110)
        self.drop_zone.pack(fill="x", padx=16, pady=4)
        self.drop_zone.pack_propagate(False)
        ctk.CTkLabel(self.drop_zone,
                     text="✨Chào mừng bạn đến với ứng dụng \n trích xuất dữ liệu file XML. \n Ứng dụng viết bởi toanbx-P.TCTH \n Hỗ trợ: 0902.985.431⭐",
                     font=ctk.CTkFont("Segoe UI", 11),
                     text_color=MUTED,
                     justify="center").place(relx=.5, rely=.4, anchor="center")
        #self.drop_zone.bind("<Button-1>", lambda e: self._pick_files())

        # Label link có thể click
        link = ctk.CTkLabel(self.drop_zone,
                     text="🌐 vietinbank.cn600.website",
                     font=ctk.CTkFont("Segoe UI", 11, underline=True),
                     text_color="#4A9EFF",
                     cursor="hand2",
                     justify="center")
        link.place(relx=.5, rely=.78, anchor="center")
        link.bind("<Button-1>", lambda e: webbrowser.open("https://vietinbank.cn600.website"))

        # Buttons
        btn_kw = dict(corner_radius=8, height=38,
                      font=ctk.CTkFont("Segoe UI", 12, "bold"))

        ctk.CTkButton(sidebar, text="📜  Chọn file XML",
                      fg_color=BLUE, hover_color=BLUE2,
                      command=self._pick_files, **btn_kw).pack(fill="x", padx=16, pady=(12,4))

        ctk.CTkButton(sidebar, text="📁  Chọn thư mục",
                      fg_color="#2A3040", hover_color="#343D52",
                      command=self._pick_folder, **btn_kw).pack(fill="x", padx=16, pady=4)

        ctk.CTkButton(sidebar, text="✅  Xử lý file",
                      fg_color=GREEN, hover_color="#218838",
                      command=self._process, **btn_kw).pack(fill="x", padx=16, pady=(12,4))

        ctk.CTkButton(sidebar, text="💾  Xuất Excel",
                      fg_color=ORANGE, hover_color="#E06500",
                      command=self._export, **btn_kw).pack(fill="x", padx=16, pady=4)

        ctk.CTkButton(sidebar, text="🗑   Xóa tất cả",
                      fg_color=RED, hover_color="#C82333",
                      command=self._clear_all, **btn_kw).pack(fill="x", padx=16, pady=4)

        # File list
        ctk.CTkLabel(sidebar, text="File đã chọn",
                     font=ctk.CTkFont("Segoe UI", 11, "bold"),
                     text_color=TEXT).pack(anchor="w", padx=20, pady=(18, 4))

        self.file_list_box = ctk.CTkScrollableFrame(sidebar, fg_color=BG,
                                                     corner_radius=8, height=200)
        self.file_list_box.pack(fill="x", padx=16, pady=(0, 8))

        # Log
        ctk.CTkLabel(sidebar, text="Nhật ký",
                     font=ctk.CTkFont("Segoe UI", 11, "bold"),
                     text_color=TEXT).pack(anchor="w", padx=20, pady=(8, 4))

        self.log_box = ctk.CTkTextbox(sidebar, fg_color=BG, text_color=MUTED,
                                      font=ctk.CTkFont("Consolas", 9),
                                      corner_radius=8, wrap="word")
        self.log_box.pack(fill="both", expand=True, padx=16, pady=(0, 16))
        self.log_box.configure(state="disabled")

        # ── Table area ──
        right = ctk.CTkFrame(content, fg_color=BG, corner_radius=0)
        right.pack(side="left", fill="both", expand=True)

        # Status bar
        self.status_bar = ctk.CTkFrame(right, fg_color=CARD, corner_radius=0, height=32)
        self.status_bar.pack(fill="x", side="bottom")
        self.lbl_status = ctk.CTkLabel(self.status_bar, text="Sẵn sàng.",
                                        font=ctk.CTkFont("Segoe UI", 10),
                                        text_color=MUTED)
        self.lbl_status.pack(side="left", padx=16, pady=4)

        # Progress bar
        self.progress = ctk.CTkProgressBar(right, fg_color=CARD,
                                            progress_color=BLUE2, height=4)
        self.progress.pack(fill="x", side="bottom")
        self.progress.set(0)

        # Table
        self.table = DataTable(right)
        self.table.pack(fill="both", expand=True)

    def _stat_badge(self, parent, label, value, color):
        f = ctk.CTkFrame(parent, fg_color=color, corner_radius=8)
        f.pack(side="left", padx=4)
        ctk.CTkLabel(f, text=label, font=ctk.CTkFont("Segoe UI", 9),
                     text_color="white").pack(padx=10, pady=(6,0))
        lbl = ctk.CTkLabel(f, text=value, font=ctk.CTkFont("Segoe UI", 14, "bold"),
                           text_color="white")
        lbl.pack(padx=10, pady=(0,6))
        return lbl

    # ── Actions ────────────────────────────────────────────────────────────

    def _pick_files(self):
        files = filedialog.askopenfilenames(
            title="Chọn file XML hóa đơn",
            filetypes=[("XML files", "*.xml"), ("All files", "*.*")]
        )
        if files:
            self._add_files(list(files))

    def _pick_folder(self):
        folder = filedialog.askdirectory(title="Chọn thư mục chứa file XML")
        if folder:
            xml_files = [
                os.path.join(folder, f)
                for f in sorted(os.listdir(folder))
                if f.lower().endswith(".xml")
            ]
            self._add_files(xml_files)

    def _add_files(self, files):
        added = 0
        for f in files:
            if f not in self._selected_files:
                self._selected_files.append(f)
                added += 1
        self._refresh_file_list()
        self._log(f"Đã thêm {added} file. Tổng: {len(self._selected_files)} file.")

    def _refresh_file_list(self):
        for w in self.file_list_box.winfo_children():
            w.destroy()
        for f in self._selected_files:
            name = os.path.basename(f)
            lbl = ctk.CTkLabel(self.file_list_box, text=f"  📄 {name}",
                               font=ctk.CTkFont("Segoe UI", 9),
                               text_color=MUTED, anchor="w")
            lbl.pack(fill="x", pady=1)

    def _process(self):
        if not self._selected_files:
            messagebox.showwarning("Chưa chọn file", "Vui lòng chọn file XML trước.")
            return
        threading.Thread(target=self._process_worker, daemon=True).start()

    def _process_worker(self):
        self._set_status("Đang xử lý...", color=ORANGE)
        self.progress.set(0)

        records = []
        existing = set()
        errors   = 0
        n        = len(self._selected_files)

        for i, path in enumerate(self._selected_files):
            fname = os.path.basename(path)
            try:
                data = read_xml(path)
                key  = f"{data['so_ct']}_{data['ky_hieu']}"
                if key in existing:
                    self._log(f"⚠ Trùng lặp: {fname}")
                else:
                    records.append(data)
                    existing.add(key)
                    self._log(f"✓ {fname}")
            except Exception as e:
                errors += 1
                self._log(f"✗ {fname}: {e}")

            self.progress.set((i + 1) / n)

        self._records = records

        # Tính tổng các cột số
        def to_float(s):
            try:
                if not s:
                    return 0.0
                # Giá trị đã được format dạng "1,100,000" → chỉ cần bỏ dấu phẩy
                cleaned = str(s).replace(",", "").replace(" ", "")
                return float(cleaned) if cleaned else 0.0
            except Exception:
                return 0.0

        tong_lit       = sum(to_float(r["so_lit"])           for r in records) / 1000
        tong_truoc     = sum(to_float(r["tien_truoc_thue"])  for r in records)
        tong_thue      = sum(to_float(r["tien_thue"])        for r in records)
        tong_sau       = sum(to_float(r["tong_tien"])        for r in records)
        tien_xang = sum(to_float(r["tong_tien"])        for r in records if to_float(r["so_lit"]) > 1)
        tien_cuoc = tong_sau - tien_xang

        def fmt_num(v):
            return f"{v:,.0f}".replace(",", ".")

        # Update table on main thread
        self.after(0, lambda: self.table.render(records))

        # Update stats
        hd = sum(1 for r in records if r["loai"] == "HOA_DON")
        bl = len(records) - hd
        self.after(0, lambda: self.lbl_total.configure(text=str(len(records))))
        self.after(0, lambda: self.lbl_hd.configure(text=str(hd)))
        self.after(0, lambda: self.lbl_bl.configure(text=str(bl)))
        self.after(0, lambda: self.lbl_so_lit.configure(text=fmt_num(tong_lit)))
        self.after(0, lambda: self.lbl_truoc_thue.configure(text=fmt_num(tong_truoc)))
        self.after(0, lambda: self.lbl_tong_thue.configure(text=fmt_num(tong_thue)))
        self.after(0, lambda: self.lbl_sau_thue.configure(text=fmt_num(tong_sau)))
        self.after(0, lambda: self.lbl_tien_xang.configure(text=fmt_num(tien_xang)))
        self.after(0, lambda: self.lbl_tien_cuoc.configure(text=fmt_num(tien_cuoc)))

        msg = f"Hoàn thành: {len(records)} bản ghi"
        if errors:
            msg += f"  |  {errors} lỗi"
        self._set_status(msg, color=GREEN if not errors else ORANGE)
        self.after(2000, lambda: self.progress.set(0))

    def _export(self):
        if not self._records:
            messagebox.showwarning("Không có dữ liệu", "Hãy xử lý file XML trước khi xuất.")
            return
        out = filedialog.asksaveasfilename(
            defaultextension=".xlsx",
            filetypes=[("Excel files", "*.xlsx")],
            initialfile="invoices_output.xlsx",
            title="Lưu file Excel"
        )
        if not out:
            return
        try:
            export_excel(self._records, out)
            self._log(f"💾 Đã xuất: {os.path.basename(out)}")
            self._set_status(f"Đã lưu: {out}", color=GREEN)
            messagebox.showinfo("Thành công", f"Đã xuất {len(self._records)} bản ghi\n→ {out}")
        except Exception as e:
            messagebox.showerror("Lỗi xuất file", str(e))

    def _clear_all(self):
        self._records = []
        self._selected_files = []
        self._refresh_file_list()
        self.table.render([])
        self.lbl_total.configure(text="0")
        self.lbl_hd.configure(text="0")
        self.lbl_bl.configure(text="0")
        self.lbl_so_lit.configure(text="0")
        self.lbl_truoc_thue.configure(text="0")
        self.lbl_tong_thue.configure(text="0")
        self.lbl_sau_thue.configure(text="0")
        self.lbl_tien_xang.configure(text="0")
        self.lbl_tien_cuoc.configure(text="0")
        self._set_status("Đã xóa.", color=MUTED)
        self._log("— Đã xóa toàn bộ —")

    def _log(self, msg):
        def _do():
            self.log_box.configure(state="normal")
            self.log_box.insert("end", msg + "\n")
            self.log_box.see("end")
            self.log_box.configure(state="disabled")
        self.after(0, _do)

    def _set_status(self, msg, color=MUTED):
        self.after(0, lambda: self.lbl_status.configure(text=msg, text_color=color))


# ─── Entry ────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    app = App()
    app.mainloop()
